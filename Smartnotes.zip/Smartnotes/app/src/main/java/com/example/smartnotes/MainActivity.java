package com.example.smartnotes;

import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.SearchManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.smartNotes.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    DatabaseManagementActivity databaseManager;
    long notesID;
    String notesTitle, notesDescription, notesDateLeft, notesTimeLeft;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toast.makeText(getApplicationContext(), "Welcome to Handy notes with Alarm!", Toast.LENGTH_SHORT).show();
        databaseManager = new DatabaseManagementActivity(this);
        getDbData(1, "ignore");
        notifyAlarmChannel();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menuValue) {
        MenuInflater menuItems = getMenuInflater();
        menuItems.inflate(R.menu.menu, menuValue);
        SearchView tempView = (SearchView) menuValue.findItem(R.id.menu_search).getActionView();
        SearchManager tempSearch = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        tempView.setSearchableInfo(tempSearch.getSearchableInfo(getComponentName()));
        tempView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String submitQuery) {
                getDbData(2, submitQuery);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String changeQuery) {
                getDbData(2, changeQuery);
                return true;
            }
        });
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case R.id.menu_help:
                AlertDialog.Builder settingsDialog = new AlertDialog.Builder(this);
                settingsDialog.setMessage("This app is developed by Gayathri Potla as part of Mobile Application Development ICA under the guidance of Julien Cordry. Please click Source Code to view the code ")
                        .setTitle("Application Developer")
                        .setNeutralButton("Source Code", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/GayathriPotla/SmartsNotes"));
                                startActivity(i);
                            }
                        })
                        .setPositiveButton("Close", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                //finish();
                            }
                        })
                        .show();
                return true;
            case R.id.menu_settings:
                AlertDialog.Builder s = new AlertDialog.Builder(this);
                s.setMessage("Are you sure want to Close SmartNotes?")
                        .setTitle("Logout")
                        .setNeutralButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        })
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                            }
                        })
                        .show();
                return true;
            default:
                return super.onOptionsItemSelected(menuItem);
        }
    }

    private void notifyAlarmChannel() {
        //https://www.tabnine.com/code/java/methods/android.app.NotificationChannel/setVibrationPattern
        String CHANNEL_ID = "AlarmID";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence channelName = getString(R.string.channel_name);
            String channelDescription = getString(R.string.channel_description);
            int setPriority = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel notificationChannel = new NotificationChannel(CHANNEL_ID, channelName, setPriority);
            notificationChannel.setDescription(channelDescription);
            notificationChannel.enableVibration(true);
            notificationChannel.setLightColor(Color.GREEN);
            notificationChannel.setVibrationPattern(new long[]{0});
            NotificationManager systemServiceNotify = getSystemService(NotificationManager.class);
            systemServiceNotify.createNotificationChannel(notificationChannel);
        }
    }

    ArrayList<AdapterActivity> listItems = new ArrayList<AdapterActivity>();
    DBAdapter databaseAdapter;

    public void getDbData(int counterValue, String searchValue) {
        listItems.clear();
        Cursor dbCursor;
        if (counterValue == 1)
            dbCursor = databaseManager.query(null, null, null, DatabaseManagementActivity.IDColumn);
        else {
            String[] ssArgs = {"%" + searchValue + "%", "%" + searchValue + "%"};
            dbCursor = databaseManager.query(null, "Title like ? or Description like ?", ssArgs, DatabaseManagementActivity.IDColumn);
        }
        if (dbCursor.moveToFirst()) {
            do {
                listItems.add(new AdapterActivity(dbCursor.getLong(dbCursor.getColumnIndex(DatabaseManagementActivity.IDColumn)),
                        dbCursor.getString(dbCursor.getColumnIndex(DatabaseManagementActivity.dateTimeColumn)),
                        dbCursor.getString(dbCursor.getColumnIndex(DatabaseManagementActivity.titleColumn)),
                        dbCursor.getString(dbCursor.getColumnIndex(DatabaseManagementActivity.DescriptionColumn)),
                        dbCursor.getString(dbCursor.getColumnIndex(DatabaseManagementActivity.alarmTimeColumn)),
                        dbCursor.getString(dbCursor.getColumnIndex(DatabaseManagementActivity.alarmDateColumn))));

            } while (dbCursor.moveToNext());
        }
        databaseAdapter = new DBAdapter(listItems);
        final ListView listItemsTemp = findViewById(R.id.listViewItems);
        listItemsTemp.setAdapter(databaseAdapter);
    }

    //TO Update the existing notes
    public void notesDataUpdate() {
        String enteredTitle = notesTitle;
        String enteredDescription = notesDescription;
        String enterednotesTitleId = String.valueOf(notesID);
        String enteredTimeLeft = notesTimeLeft;
        String enteredselectedDaysLeft = notesDateLeft;
        Intent updateNotesIntent = new Intent(getApplicationContext(), AlarmManagementActivity.class);
        updateNotesIntent.putExtra("prefTitle", enteredTitle);
        updateNotesIntent.putExtra("prefDescription", enteredDescription);
        updateNotesIntent.putExtra("prefUpdates", "notificationUpdate");
        updateNotesIntent.putExtra("prefId", enterednotesTitleId);
        updateNotesIntent.putExtra("prefTime", enteredTimeLeft);
        updateNotesIntent.putExtra("prefDate", enteredselectedDaysLeft);
        startActivityForResult(updateNotesIntent, 4);
    }

    //Add New Note
    public void AddNewNotesActivity(View v) {
        notesID = databaseManager.RowCount() + 1;
        //Toast.makeText(getApplicationContext(),"TODO ADD ITEMS",Toast.LENGTH_SHORT).show();
        String enterednotesTitleId = String.valueOf(notesID);
        Intent updateNotesIntent = new Intent(getApplicationContext(), AlarmManagementActivity.class);
        updateNotesIntent.putExtra("prefTitle", "ignore");
        updateNotesIntent.putExtra("prefDescription", "ignore");
        updateNotesIntent.putExtra("prefUpdates", "ADD");
        updateNotesIntent.putExtra("prefId", enterednotesTitleId);
        updateNotesIntent.putExtra("prefTime", "ignore");
        updateNotesIntent.putExtra("prefDate", "ignore");
        startActivityForResult(updateNotesIntent, 3);
    }

    @Override
    protected void onActivityResult(int id, int responseId, Intent data) {
        super.onActivityResult(id, responseId, data);
        if (id == 3) {
            getDbData(1, "ignore");
            notesID = 0;
        } else if (id == 4) {
            getDbData(1, "ignore");
            notesID = 0;
        }
    }

    private class DBAdapter extends BaseAdapter {
        public ArrayList<AdapterActivity> listItemsAdpater;

        public DBAdapter(ArrayList<AdapterActivity> listItemsAdpater) {
            this.listItemsAdpater = listItemsAdpater;
        }

        @Override
        public int getCount() {
            return listItemsAdpater.size();
        }

        @Override
        public String getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        TextView totalTimeLeft, latestTitle, latestDescription;

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            LayoutInflater dbInflater = getLayoutInflater();
            View dbView = dbInflater.inflate(R.layout.each_notes_layout, null);
            final AdapterActivity temp = listItemsAdpater.get(position);
            String totalLeft = temp.Time + " " + temp.Date;
            totalTimeLeft = dbView.findViewById(R.id.tempTimeLeft);
            if (temp.Time.equalsIgnoreCase("notset"))
                totalTimeLeft.setVisibility(View.GONE);
            else {
                totalTimeLeft.setVisibility(View.VISIBLE);
                totalTimeLeft.setText(totalLeft);
            }
            latestTitle = dbView.findViewById(R.id.tempTitleView);
            latestTitle.setText(temp.Title);
            latestTitle.setSelected(true);

            latestDescription = dbView.findViewById(R.id.tempDescriptionView);
            latestDescription.setText(temp.Description);
            latestDescription.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    notesID = temp.ID;
                    notesTitle = temp.Title;
                    notesDescription = temp.Description;
                    notesDateLeft = temp.Date;
                    notesTimeLeft = temp.Time;
                    notesDataUpdate();
                }
            });
            return dbView;
        }
    }
}
