package com.example.smartnotes;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if(i.getAction().equalsIgnoreCase("com.example.alarmReceiver")) {
            AlarmSoundsManagerActivity.getInstance(c).stopMusic();
        }
    }
}
