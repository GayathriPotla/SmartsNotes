package com.example.smartnotes;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.fragment.app.DialogFragment;
import com.example.smartNotes.R;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class SetAlarmInfoActivity extends DialogFragment{
    View v;
    TextView displayTime, displayDate;
    ImageButton backButton, selectTime, selectDate;
    Button deleteAlarm, saveAlarm;
    String getTime, getDate;

    @Override
    public View onCreateView(LayoutInflater li, ViewGroup viewGroup,
                             Bundle bundle) {
        v = li.inflate(R.layout.get_information, viewGroup, false);
        backButton = v.findViewById(R.id.backButton);
        selectTime = v.findViewById(R.id.selectTime);
        selectDate = v.findViewById(R.id.selectDate);
        deleteAlarm = v.findViewById(R.id.deleteAlarm);
        saveAlarm = v.findViewById(R.id.saveAlarm);
        displayTime = v.findViewById(R.id.displayTime);
        displayDate = v.findViewById(R.id.displayDate);
        
        if (getArguments() != null && !TextUtils.isEmpty(getArguments().getString("timeData")))
            getTime = getArguments().getString("timeData");
        if (getArguments() != null && !TextUtils.isEmpty(getArguments().getString("dateData")))
            getDate = getArguments().getString("dateData");


        SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm", Locale.getDefault()),
                dateFormat2 = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
        String liveTime = dateFormat.format(new Date()),  liveTime2 = dateFormat2.format(new Date());

        if(getTime.equalsIgnoreCase("ignore")) displayTime.setText(liveTime);
        else displayTime.setText(getTime);

        if(getDate.equalsIgnoreCase("ignore")) displayDate.setText(liveTime2);
        else displayDate.setText(getDate);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });

        selectTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                androidx.fragment.app.FragmentManager fManager1 = getFragmentManager();
                SetAlarmTimeActivity timeAc = new SetAlarmTimeActivity();
                Bundle b = new Bundle();
                b.putString("timeData1", getTime);
                b.putString("dateData1", getDate);
                timeAc.setArguments(b);
                timeAc.show(fManager1,"fragment: time picker");
                dismiss();
            }
        });
        selectDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                androidx.fragment.app.FragmentManager fManager2=getFragmentManager();
                SetAlarmDateActivity dateAc=new SetAlarmDateActivity();
                Bundle b = new Bundle();
                b.putString("timeData", getTime);
                b.putString("dateData", getDate);
                dateAc.setArguments(b);

                dateAc.show(fManager2,"Date Picker Fragment Show");
                dismiss();
            }
        });
        deleteAlarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getContext(),"Your Alarm is Removed!",Toast.LENGTH_SHORT).show();
                AlarmManagementActivity alarm=(AlarmManagementActivity)getActivity();
                alarm.removeAlarm();
                dismiss();
            }
        });
        saveAlarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getContext(),"Your Alarm Saved!",Toast.LENGTH_SHORT).show();
                AlarmManagementActivity alarm=(AlarmManagementActivity)getActivity();
                alarm.setDateTime(displayTime.getText().toString(),displayDate.getText().toString());
                dismiss();
            }
        });
        return v;
    }
}
