package com.example.smartnotes;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.widget.Toast;

public class DatabaseManagementActivity {
    // Code reference from https://developer.android.com/reference/android/database/DatabaseUtils  & https://www.tutorialspoint.com/android/android_sqlite_database.htm
    private final SQLiteDatabase sqlDB;
    static final String databaseName="smart_notes";
    static final String tableName="Notes";
    static final String dateTimeColumn="DateTime";
    static final String titleColumn="Title";
    static final String DescriptionColumn="Description";
    static final String alarmTimeColumn="Time";
    static final String alarmDateColumn="Date";
    static final String IDColumn="ID";
    static final int version=1;
    static final String createNewTable="Create table IF NOT EXISTS "+ tableName + "(ID integer primary key autoincrement," + dateTimeColumn+
            " text," + titleColumn +" text," + DescriptionColumn +" text,"+ alarmTimeColumn +" text," + alarmDateColumn + " text);";

    static class DBHelper extends SQLiteOpenHelper{
        Context c;
        DBHelper(Context c){
            super(c, databaseName,null, version);
            this.c = c;
        }
        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(createNewTable);
        }
        // reference from https://stackoverflow.com/questions/29949345/how-to-initiate-the-call-onupgradesqlitedatabase-db-int-oldversion-int-newver
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("Drop table IF EXISTS " + tableName);
            onCreate(db);
        }
    }

    DatabaseManagementActivity(Context c){
        DBHelper db=new DBHelper(c);
        sqlDB=db.getWritableDatabase();
    }
    
    public long Insert(ContentValues content){
        long l = sqlDB.insert(tableName,"",content);
        return l;
    }
    //p- projection , s - selection , sort-sort order in db
    public Cursor query(String[] p, String s, String[] sArgs, String sort){
        SQLiteQueryBuilder qb=new SQLiteQueryBuilder();
        qb.setTables(tableName);
        Cursor pointer=qb.query(sqlDB,p,s,sArgs,null,null,sort);
        return pointer;
    }

    public int Delete(String s, String[] sArgs){
        int temp=sqlDB.delete(tableName,s,sArgs);
        return temp;
    }
    public int Update(ContentValues values, String s, String[] sArgs){
        int temp=sqlDB.update(tableName,values,s,sArgs);
        return temp;
    }

    public long RowCount(){
        long temp= DatabaseUtils.queryNumEntries(sqlDB,tableName);
        return temp;
    }
}
