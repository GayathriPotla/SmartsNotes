package com.example.smartnotes;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import com.example.smartNotes.R;

public class alarmReceiverActivity extends BroadcastReceiver {

    @Override
    public void onReceive(Context c, Intent i) {
        if(i.getAction().equalsIgnoreCase("com.example.leftTime")) {
            Bundle b1 = i.getExtras();
            Integer notiID = Integer.parseInt(b1.getString("notificationID"));
            System.out.println(" NotificationID: " + notiID);
          if(b1.getString("SetNotify").equalsIgnoreCase("SetNotification")){
              Intent notifyIntent = new Intent(c, AlarmManagementActivity.class);
              notifyIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

              notifyIntent.putExtra("prefTitle",b1.getString("notificationTitle"));
              notifyIntent.putExtra("prefDescription",b1.getString("notificationDescription"));
              notifyIntent.putExtra("prefUpdates","notificationUpdate");
              notifyIntent.putExtra("prefId",b1.getString("notificationID"));
              notifyIntent.putExtra("prefTime",b1.getString("notificationTimeLeft"));
              notifyIntent.putExtra("prefDate",b1.getString("notificationDateLeft"));

            AlarmSoundsManagerActivity.getInstance(c).playMusic();
            String cID = "AlarmID";
            String GROUP_KEY = "com.android.example.KEY";
            PendingIntent pendingIntent1 = PendingIntent.getActivity(c, notiID, notifyIntent, 0);

            Intent intent_snooze = new Intent(c, AlarmReceiver.class);
            intent_snooze.setAction("com.example.alarmReceiver");
            intent_snooze.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent pendingSwitchIntent = PendingIntent.getBroadcast(c, notiID, intent_snooze, 0);
            
            NotificationCompat.Action action =
                    new NotificationCompat.Action.Builder(R.drawable.reminder_icon_yellow,
                            "SNOOZE", pendingSwitchIntent)
                            .build();

            NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(c, cID)
                    .setSmallIcon(R.drawable.time_picker_icon_small)
                    .setColor(ContextCompat.getColor(c, R.color.notificationColor))
                    .setContentTitle(b1.getString("notificationTitle"))
                    .setStyle(new NotificationCompat.InboxStyle()
                    .addLine(b1.getString("notificationDescription"))
                    .setBigContentTitle(b1.getString("notificationTitle")))
                    .setContentIntent(pendingIntent1)
                    .setLights(Color.RED, 3000, 3000)
                    .setVibrate(new long[] { 0, 1000, 1000, 1000, 1000 })
                    .setAutoCancel(true)
                    .addAction(action)
                    .setGroup(GROUP_KEY)
                    .setGroupSummary(true);
            NotificationManagerCompat nm = NotificationManagerCompat.from(c);
            nm.notify(notiID, notificationBuilder.build());
          }
          else{
                NotificationManagerCompat notificationManager1 = NotificationManagerCompat.from(c);
                notificationManager1.cancel(notiID);
            }
        }
        else if(i.getAction().equalsIgnoreCase("android.intent.action.BOOT_COMPLETED")){
            Toast.makeText(c, "AlarmMessage: Reboot successful", Toast.LENGTH_SHORT).show();
        }
    }
}


