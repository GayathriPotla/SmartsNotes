package com.example.smartnotes;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.smartNotes.R;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class AlarmManagementActivity extends AppCompatActivity {
    private static final String CHANNEL_ID = "Alarm";
    DatabaseManagementActivity databaseManagementActivity;
    Button update,remove;
    String add, inputTitle, inputDescription, inputRecordid, inputAlarmDate, inputAlarmTime;
    EditText mainTitle, mainDescription;
    Integer inputRecordid2;
    TextView alarmTime, alarmDate;
    public static String leftTime, leftDate;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        String ig="ignore";
        databaseManagementActivity =new DatabaseManagementActivity(this);
        update = findViewById(R.id.add_update_button1);
        remove = findViewById(R.id.cancel_button1);
        mainTitle = findViewById(R.id.mainTitle);
        mainDescription = findViewById(R.id.mainDescription);
        alarmTime = findViewById(R.id.prefTime1);
        alarmDate = findViewById(R.id.prefDate1);

        alarmTime.setVisibility(View.GONE);
        alarmDate.setVisibility(View.GONE);
        alarmTime.setText(ig);
        alarmDate.setText(ig);

        Bundle b1 = getIntent().getExtras();
        inputTitle = b1.getString("prefTitle");
        inputDescription = b1.getString("prefDescription");
        add = b1.getString("prefUpdates");
        inputRecordid = b1.getString("prefId");
        inputAlarmTime = b1.getString("prefTime");
        inputAlarmDate = b1.getString("prefDate");
        inputRecordid2 = Integer.parseInt(inputRecordid);
        if(add.equals("notificationUpdate")){
            mainTitle.setText(inputTitle);
            mainDescription.setText(inputDescription);
            if(!inputAlarmTime.equalsIgnoreCase("notset")) {
                alarmTime.setVisibility(View.VISIBLE);
                alarmDate.setVisibility(View.VISIBLE);
                alarmTime.setText(inputAlarmTime);
                alarmDate.setText(inputAlarmDate);
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater mi = getMenuInflater();
        mi.inflate(R.menu.menu1,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem i) {
        switch (i.getItemId()){
            case R.id.menu_reminder:
                androidx.fragment.app.FragmentManager fm = getSupportFragmentManager();
                SetAlarmInfoActivity setAlarmInfoActivity =new SetAlarmInfoActivity();
                Bundle b = new Bundle();
                b.putString("timeData", alarmTime.getText().toString());
                b.putString("dateData", alarmDate.getText().toString());
                setAlarmInfoActivity.setArguments(b);
                setAlarmInfoActivity.show(fm,"Show Fragment");
                return true;

            case R.id.menu_delete:
                if(add.equals("notificationUpdate")) {
                    AlertDialog.Builder info1=new AlertDialog.Builder(this);
                    info1.setMessage("Are you sure you want to delete this note?")
                            .setTitle("Warning")
                            .setNeutralButton("YES", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    removeCurrentNote(inputRecordid);
                                }
                            })
                            .setPositiveButton("CANCEL", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                }
                            })
                            .show();
                }
                else
                    Toast.makeText(getApplicationContext(),"Your notes is not yet added!",Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onOptionsItemSelected(i);
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public void SetAlarm(String ta, String da, String tr, String dr){
        String[] timeItems = ta.split(":",2);
        String[] dateArr = da.split("-",3);

        int Hour = Integer.parseInt(timeItems[0]);
        int Minute = Integer.parseInt(timeItems[1]);
        int selectedYear = Integer.parseInt(dateArr[2]);
        int selectedMonth = Integer.parseInt(dateArr[1])-1;
        int selectedDay = Integer.parseInt(dateArr[0]);

        System.out.println("Updating Alarm for "+inputRecordid2+"at "+Hour+":"+Minute+" and "+selectedDay+"-"+ Integer.valueOf(selectedMonth + 1) +"-"+selectedYear);
        Calendar agenda = Calendar.getInstance();
        agenda.set(Calendar.YEAR, selectedYear);
        agenda.set(Calendar.MONTH, selectedMonth);
        agenda.set(Calendar.DAY_OF_MONTH, selectedDay);
        agenda.set(Calendar.HOUR_OF_DAY, Hour);
        agenda.set(Calendar.MINUTE, Minute);
        agenda.set(Calendar.SECOND, 0);
        agenda.set(Calendar.MILLISECOND, 0);

        AlarmManager alarmManager = (AlarmManager)getSystemService  (Context.ALARM_SERVICE);
        Intent i = new Intent(this, alarmReceiverActivity.class);
        i.setAction("com.example.leftTime");
        String message="SmartNotes";
        i.putExtra("AlarmMessage",message);
        i.putExtra("notificationID",inputRecordid);
        i.putExtra("notificationTitle",tr);
        i.putExtra("notificationDescription",dr);
        i.putExtra("notificationTimeLeft",ta);
        i.putExtra("notificationDateLeft",da);
        i.putExtra("SetNotify","SetNotification");

        PendingIntent pi = PendingIntent.getBroadcast(this, inputRecordid2, i,0);
        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, agenda.getTimeInMillis(), pi);
    }

    public void removeTheAlarm(){
        AlarmManager alarmManager = (AlarmManager)getSystemService (Context.ALARM_SERVICE);

        Intent i = new Intent(this, alarmReceiverActivity.class);
        i.setAction("com.example.leftTime");
        String msg1="Hello from SmartNotes";
        i.putExtra("AlarmMessage",msg1);
        i.putExtra("notificationID",inputRecordid);
        i.putExtra("notificationTitle","ignore");
        i.putExtra("notificationDescription","ignore");
        i.putExtra("notificationTimeLeft","ignore");
        i.putExtra("notificationDateLeft","ignore");
        i.putExtra("SetNotify","SetNotificationNot");

        PendingIntent p = PendingIntent.getBroadcast(this, inputRecordid2, i,0);
        assert alarmManager != null;
        alarmManager.cancel(p);
    }


    public void removeCurrentNote(String ID1){
        String[] sArgs={ID1};
        int temp= databaseManagementActivity.Delete("ID=?", sArgs);
        if (temp >0) {
            finish();
            removeTheAlarm();
            Toast.makeText(getApplicationContext(),"Your notes removed successfully!",Toast.LENGTH_SHORT).show();
        }
        else
            Toast.makeText(getApplicationContext(),"Oops! Unable to remove notes",Toast.LENGTH_SHORT).show();
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public void updateNotesOnButtonClick(View view) {
        if(!add.equals("notificationUpdate")){
            updateDataToDB();
        }
        else updateDB2();
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public void updateDataToDB(){
        if (!mainTitle.getText().toString().equals("") && !mainDescription.getText().toString().equals("")) {
            ContentValues cv = new ContentValues();
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            String currentDateandTime = df.format(new Date());
            cv.put(DatabaseManagementActivity.dateTimeColumn, currentDateandTime);
            cv.put(DatabaseManagementActivity.titleColumn, mainTitle.getText().toString());
            cv.put(DatabaseManagementActivity.DescriptionColumn, mainDescription.getText().toString());

            if(!alarmTime.getText().toString().equalsIgnoreCase("ignore")) {
                cv.put(DatabaseManagementActivity.alarmTimeColumn, alarmTime.getText().toString());
                cv.put(DatabaseManagementActivity.alarmDateColumn, alarmDate.getText().toString());
                SetAlarm(alarmTime.getText().toString(), alarmDate.getText().toString(),mainTitle.getText().toString(),mainDescription.getText().toString());
            } else{
                cv.put(DatabaseManagementActivity.alarmTimeColumn, "notset");
                cv.put(DatabaseManagementActivity.alarmDateColumn, "notset");
            }
            long temp = databaseManagementActivity.Insert(cv);
            if (temp > 0) {
                Toast.makeText(getApplicationContext(), "Added Notes Successfully", Toast.LENGTH_SHORT).show();
                finish();
            } else Toast.makeText(getApplicationContext(), "Oops! failed to add notes", Toast.LENGTH_SHORT).show();
        }
        else Toast.makeText(getApplicationContext(), "Check your empty fields", Toast.LENGTH_SHORT).show();
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public void updateDB2(){
        if (!mainTitle.getText().toString().equals("") && !mainDescription.getText().toString().equals("")) {
            ContentValues cv = new ContentValues();
            SimpleDateFormat dateFormat2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            String currentDateandTime = dateFormat2.format(new Date());

            cv.put(DatabaseManagementActivity.dateTimeColumn, currentDateandTime);
            cv.put(DatabaseManagementActivity.titleColumn, mainTitle.getText().toString());
            cv.put(DatabaseManagementActivity.DescriptionColumn, mainDescription.getText().toString());
            cv.put(DatabaseManagementActivity.IDColumn, inputRecordid2);

            if(!alarmTime.getText().toString().equalsIgnoreCase("ignore")) {
                cv.put(DatabaseManagementActivity.alarmTimeColumn, alarmTime.getText().toString());
                cv.put(DatabaseManagementActivity.alarmDateColumn, alarmDate.getText().toString());
                SetAlarm(alarmTime.getText().toString(), alarmDate.getText().toString(),mainTitle.getText().toString(),mainDescription.getText().toString());
            }
            else{
                cv.put(DatabaseManagementActivity.alarmTimeColumn, "notset");
                cv.put(DatabaseManagementActivity.alarmDateColumn, "notset");
                removeTheAlarm();
            }

            String[] selected = {String.valueOf(inputRecordid2)};
            int temp2 = databaseManagementActivity.Update(cv, "ID=?", selected);
            long id = databaseManagementActivity.Insert(cv);
            if (temp2 > 0) {
                Toast.makeText(this, "Notes updated successfully", Toast.LENGTH_SHORT).show();
                finish();
            } else Toast.makeText(getApplicationContext(), "Select a notes to update", Toast.LENGTH_SHORT).show();
        }
        else Toast.makeText(getApplicationContext(), "One or more fields are empty", Toast.LENGTH_SHORT).show();
    }
    public void cancel(View v) {
        finish();
    }

    public void setDateTime(String t,String d){
        alarmTime.setText(t);
        alarmDate.setText(d);
        alarmTime.setVisibility(View.VISIBLE);
        alarmDate.setVisibility(View.VISIBLE);
    }

    public void removeAlarm(){
        alarmTime.setVisibility(View.GONE);
        alarmDate.setVisibility(View.GONE);
        String i="ignore";
        alarmTime.setText(i);
        alarmDate.setText(i);
    }
}
