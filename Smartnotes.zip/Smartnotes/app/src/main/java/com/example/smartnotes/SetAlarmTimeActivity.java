package com.example.smartnotes;

import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TimePicker;

import androidx.annotation.RequiresApi;
import androidx.fragment.app.DialogFragment;

import com.example.smartNotes.R;

public class SetAlarmTimeActivity extends DialogFragment{
    View v;
    Button slectedTime,removeSlectedTime;
    TimePicker picker;
    String time,date;

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        v=inflater.inflate(R.layout.get_time, container, false);
        slectedTime= v.findViewById(R.id.time_save_picker);
        removeSlectedTime= v.findViewById(R.id.time_cancel_picker);
        picker= v.findViewById(R.id.tp);

        if (getArguments() != null && !TextUtils.isEmpty(getArguments().getString("timeData1")))
            time=getArguments().getString("timeData1");
        if (getArguments() != null && !TextUtils.isEmpty(getArguments().getString("dateData1")))
            date=getArguments().getString("dateData1");

        if(!time.equalsIgnoreCase("ignore")) {
            String[] time_arr = time.split(":", 2);
            int h = Integer.parseInt(time_arr[0]);
            int m = Integer.parseInt(time_arr[1]);
            picker.setHour(h);
            picker.setMinute(m);
        }

        slectedTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String timeOn=picker.getHour()+":"+picker.getMinute();
                String[] time_arr = timeOn.split(":",2);
                androidx.fragment.app.FragmentManager fm5 = getFragmentManager();
                SetAlarmInfoActivity alarm=new SetAlarmInfoActivity();
                Bundle b = new Bundle();
                b.putString("timeData",timeOn);
                b.putString("dateData", date);
                alarm.setArguments(b);
                assert fm5 != null;
                alarm.show(fm5,"Back to dialog save time");
                dismiss();
            }
        });
        removeSlectedTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                androidx.fragment.app.FragmentManager fm6 = getFragmentManager();
                SetAlarmInfoActivity alarm=new SetAlarmInfoActivity();
                Bundle b = new Bundle();
                b.putString("timeData",time);
                b.putString("dateData", date);
                alarm.setArguments(b);
                assert fm6 != null;
                alarm.show(fm6,"Back to dialog cancel time");
                dismiss();
            }
        });
        return v;
    }
}
