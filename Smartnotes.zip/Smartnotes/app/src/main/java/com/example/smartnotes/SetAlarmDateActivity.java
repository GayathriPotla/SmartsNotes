package com.example.smartnotes;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;

import androidx.fragment.app.DialogFragment;

import com.example.smartNotes.R;

public class SetAlarmDateActivity extends DialogFragment{
    Button pickDate, pickDate_Cancel;
    DatePicker datePicker;
    String getDateTime, getDate;
    View v;

    @Override
    public View onCreateView(LayoutInflater inf, ViewGroup vg,
                             Bundle state) {

        v = inf.inflate(R.layout.get_date, vg, false);
        pickDate = v.findViewById(R.id.date_save_picker);
        pickDate_Cancel = v.findViewById(R.id.cancelDatePick);
        datePicker = v.findViewById(R.id.dp);
        if (getArguments() != null && !TextUtils.isEmpty(getArguments().getString("timeData")))
            getDateTime = getArguments().getString("timeData");
        if (getArguments() != null && !TextUtils.isEmpty(getArguments().getString("dateData")))
            getDate = getArguments().getString("dateData");

        
        if(!getDate.equalsIgnoreCase("ignore")) {
            String[] dateItem = getDate.split("-", 3);
            // test date items array
            /* for (String item : dateItem)
                System.out.println("This Activity:" + item);
             */
            int selectedYear = Integer.parseInt(dateItem[2]);
            int selectedMonth = Integer.parseInt(dateItem[1]);
            int selectedDay = Integer.parseInt(dateItem[0]);
            datePicker.updateDate(selectedYear - 1 + 1, selectedMonth - 1, selectedDay - 1 + 1);
        }
        pickDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer month=Integer.parseInt(String.valueOf(datePicker.getMonth()))+1;
                String dayOfMonth=datePicker.getDayOfMonth()+"-"+ month +"-"+datePicker.getYear();
                String[] dateItem = dayOfMonth.split("-",3);
                // test date items array
//                for (String item : dateItem)
//                    System.out.println("This Activity:" +item);
                
                androidx.fragment.app.FragmentManager fManager7 = getFragmentManager();
                SetAlarmInfoActivity alarmInfo7 = new SetAlarmInfoActivity();
                Bundle b = new Bundle();
                b.putString("timeData", getDateTime);
                b.putString("dateData", dayOfMonth);
                alarmInfo7.setArguments(b);
                assert fManager7 != null;
                alarmInfo7.show(fManager7,"save date");
                dismiss();
            }
        });

        pickDate_Cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                androidx.fragment.app.FragmentManager fManager8 = getFragmentManager();
                SetAlarmInfoActivity alarmInfo8 = new SetAlarmInfoActivity();
                Bundle b = new Bundle();
                b.putString("timeData", getDateTime);
                b.putString("dateData", getDate);
                alarmInfo8.setArguments(b);
                assert fManager8 != null;
                alarmInfo8.show(fManager8,"cancel save date");
                dismiss();
            }
        });
        return v;
    }
}
