package com.example.smartnotes;

import android.content.Context;
import android.media.MediaPlayer;

import com.example.smartNotes.R;

public class AlarmSoundsManagerActivity {
    private static AlarmSoundsManagerActivity alarmInstance;
    private final Context context;
    private MediaPlayer sound;
    public AlarmSoundsManagerActivity(Context c) {
        this.context = c;
    }
// Reference from https://developer.android.com/training/scheduling/alarms
    public static AlarmSoundsManagerActivity getInstance(Context context) {
        if (alarmInstance == null) {
            alarmInstance = new AlarmSoundsManagerActivity(context);
        }
        return alarmInstance;
    }

    public void playMusic() {
        sound = MediaPlayer.create(context, R.raw.smoke_beep);
        sound.start();
    }

    public void stopMusic() {
        if(sound != null) {
            sound.stop();
            sound.seekTo(0);
        }
    }
}
